clc
clear
%calculate and plot strains
% load('0densplot')
load('Tr5plPA0_plot')


Eps1=zeros(3,nel8);



s1_xx=1/3*(Sigma8_xx(:,1)+Sigma8_xx(:,2)+Sigma8_xx(:,3));
s1_xy=1/3*(Sigma8_xy(:,1)+Sigma8_xy(:,2)+Sigma8_xy(:,3));
s1_yy=1/3*(Sigma8_yy(:,1)+Sigma8_yy(:,2)+Sigma8_yy(:,3));





for iel=1:nel8
    
    mu=mat_el8(iel,1);
    lambda=mat_el8(iel,2);
    D=[2*mu+lambda, lambda, 0; lambda, 2*mu+lambda, 0; 0, 0, mu];
    
    Eps1(:,iel)=D\[s1_xx(iel);s1_yy(iel);s1_xy(iel)];
    

end



e1_xx=Eps1(1,:)';
e1_yy=Eps1(2,:)';
e1_xy=Eps1(3,:)';

epsilon1=0.1;
    index_top1=find(nodes(:,2)<=H+epsilon1 & nodes(:,2)>=H-epsilon1);
pr=sortrows([nodes9(index_obl,1),index_obl]);
index_obl=pr(:,2);
pr=sortrows([nodes9(index_oblm2,1),index_oblm2]);
index_oblm2=pr(:,2);
pr=sortrows([nodes9(index_right,2),index_right]);
index_right=pr(:,2);
pr=sortrows([nodes9(index_top1,1),index_top1]);
index_top1=pr(:,2);
pr=sortrows([nodes9(index_tob,1),index_tob]);
index_tob=pr(:,2);
index_obl=[index_obl;index_tob(1)];
pr=sortrows([nodes9(index_top,1),index_top]);
index_top=pr(:,2);
pr=sortrows([nodes9(index_top1m2,1),index_top1m2]);
index_top1m2=pr(:,2); 
pr=sortrows([nodes9(index_top2m2,1),index_top2m2]);
index_top2m2=pr(:,2);

index_top4=find(nodes4(:,2)>=B1(2)-0.5 & nodes4(:,2)<=B1(2)+0.5);
pr=sortrows([nodes9(index_top4,1),index_top4]);
index_top4=pr(:,2);
b=B1(2)-a*B1(1);
index_obl3=find(nodes4(:,2)<= a*nodes4(:,1)+b+epsilon & nodes4(:,2)>= ...
    a*nodes4(:,1)+b-epsilon & nodes4(:,2) >= nodes4(index_top2m2(end),2)-epsilon1); 
pr=sortrows([nodes9(index_obl3,1),index_obl3]);
index_obl3=pr(:,2);

index_top5=find(nodes6(:,2)>=PB1(2)-0.5 & nodes6(:,2)<=PB1(2)+0.5);
pr=sortrows([nodes9(index_top5,1),index_top5]);
index_top5=pr(:,2);
b=PB1(2)-a*PB1(1);
index_obl4=find(nodes6(:,2)<= a*nodes6(:,1)+b+2*epsilon/3 & nodes6(:,2)>= ...
    a*nodes6(:,1)+b-2*epsilon/3 & nodes6(:,2) >= nodes6(index_top2m2(end),2)-epsilon1); 
pr=sortrows([nodes9(index_obl4,1),index_obl4]);
index_obl4=pr(:,2);
pr=find(nodes9(:,2)<=285.861+0.1 & nodes9(:,2)>=285.861-0.1 & nodes9(:,1)>= 833.229-0.1 & nodes9(:,1)<= 833.229+0.1);
index_obl4=[index_obl4;pr];

index_top6=find(nodes8(:,2)>=PB2(2)-0.5 & nodes8(:,2)<=PB2(2)+0.5);
pr=sortrows([nodes9(index_top6,1),index_top6]);
index_top6=pr(:,2);
b=PB2(2)-a*PB2(1);
index_obl5=find(nodes8(:,2)<= a*nodes8(:,1)+b+epsilon & nodes8(:,2)>= ...
    a*nodes8(:,1)+b-epsilon & nodes8(:,2) >= nodes8(index_top2m2(end),2)-epsilon1+2); 
pr=sortrows([nodes9(index_obl5,1),index_obl5]);
index_obl5=pr(:,2);

figure(1)
hold on
    trisurf(elems8,nodes9(:,1),nodes9(:,2),0*nodes9(:,1),e1_xx)
title('\epsilon_{xx}, 5 platforms, PA=0')
xlabel('x(m)')
ylabel('y(m)')
view(2)
colormap(plasma)
colorbar
hcb=colorbar;
colorTitleHandle = get(hcb,'Title');
titleString = '\epsilon_{xx}';
set(colorTitleHandle ,'String',titleString);
caxis([0 0.02])
shading flat
axis equal
plot(nodes9(index_bottom2,1),nodes9(index_bottom2,2),'k','LineWidth',1.8)
plot(nodes9(index_left8,1),nodes9(index_left8,2),'k','LineWidth',1.8)
plot(nodes9(index_obl,1),nodes9(index_obl,2),'k','LineWidth',1.8)
plot(nodes9(index_oblm2,1),nodes9(index_oblm2,2),'k','LineWidth',1.8)
plot(nodes9(index_right,1),nodes9(index_right,2),'k','LineWidth',1.8)
plot(nodes9(index_top1,1),nodes9(index_top1,2),'k','LineWidth',1.8)
plot(nodes9(index_top1m2,1),nodes9(index_top1m2,2),'k','LineWidth',1.8)
plot(nodes9(index_top,1),nodes9(index_top,2),'k','LineWidth',1.8)
plot(nodes9(index_top4,1),nodes9(index_top4,2),'k','LineWidth',1.8)
plot(nodes9(index_obl3,1),nodes9(index_obl3,2),'k','LineWidth',1.8)
plot(nodes9(index_top5,1),nodes9(index_top5,2),'k','LineWidth',1.8)
plot(nodes9(index_obl4,1),nodes9(index_obl4,2),'k','LineWidth',1.8)
plot(nodes9(index_top6,1),nodes9(index_top6,2),'k','LineWidth',1.8)
plot(nodes9(index_obl5,1),nodes9(index_obl5,2),'k','LineWidth',1.8)
pbaspect([3 1 1])

figure(2)
hold on
    trisurf(elems8,nodes9(:,1),nodes9(:,2),0*nodes9(:,1),e1_yy)
title('\epsilon_{yy}, 5 platforms, PA=0')
xlabel('x(m)')
ylabel('y(m)')
view(2)
colormap(flipud(plasma))
colorbar
hcb=colorbar;
colorTitleHandle = get(hcb,'Title');
titleString = '\epsilon_{yy}';
set(colorTitleHandle ,'String',titleString);
caxis([-0.1 0])
shading flat
axis equal
plot(nodes9(index_bottom2,1),nodes9(index_bottom2,2),'k','LineWidth',1.8)
plot(nodes9(index_left8,1),nodes9(index_left8,2),'k','LineWidth',1.8)
plot(nodes9(index_obl,1),nodes9(index_obl,2),'k','LineWidth',1.8)
plot(nodes9(index_oblm2,1),nodes9(index_oblm2,2),'k','LineWidth',1.8)
plot(nodes9(index_right,1),nodes9(index_right,2),'k','LineWidth',1.8)
plot(nodes9(index_top1,1),nodes9(index_top1,2),'k','LineWidth',1.8)
plot(nodes9(index_top1m2,1),nodes9(index_top1m2,2),'k','LineWidth',1.8)
plot(nodes9(index_top,1),nodes9(index_top,2),'k','LineWidth',1.8)
plot(nodes9(index_top4,1),nodes9(index_top4,2),'k','LineWidth',1.8)
plot(nodes9(index_obl3,1),nodes9(index_obl3,2),'k','LineWidth',1.8)
plot(nodes9(index_top5,1),nodes9(index_top5,2),'k','LineWidth',1.8)
plot(nodes9(index_obl4,1),nodes9(index_obl4,2),'k','LineWidth',1.8)
plot(nodes9(index_top6,1),nodes9(index_top6,2),'k','LineWidth',1.8)
plot(nodes9(index_obl5,1),nodes9(index_obl5,2),'k','LineWidth',1.8)
pbaspect([3 1 1])

figure(3)
hold on
    trisurf(elems8,nodes9(:,1),nodes9(:,2),0*nodes9(:,1),e1_xy)
title('\epsilon_{xy}, 5 platforms, PA=0')
xlabel('x(m)')
ylabel('y(m)')
view(2)
colormap(flipud(plasma))
colorbar
hcb=colorbar;
colorTitleHandle = get(hcb,'Title');
titleString = '\epsilon_{xy}';
set(colorTitleHandle ,'String',titleString);
caxis([-0.012 0.0018])
shading flat
axis equal
plot(nodes9(index_bottom2,1),nodes9(index_bottom2,2),'k','LineWidth',1.8)
plot(nodes9(index_left8,1),nodes9(index_left8,2),'k','LineWidth',1.8)
plot(nodes9(index_obl,1),nodes9(index_obl,2),'k','LineWidth',1.8)
plot(nodes9(index_oblm2,1),nodes9(index_oblm2,2),'k','LineWidth',1.8)
plot(nodes9(index_right,1),nodes9(index_right,2),'k','LineWidth',1.8)
plot(nodes9(index_top1,1),nodes9(index_top1,2),'k','LineWidth',1.8)
plot(nodes9(index_top1m2,1),nodes9(index_top1m2,2),'k','LineWidth',1.8)
plot(nodes9(index_top,1),nodes9(index_top,2),'k','LineWidth',1.8)
plot(nodes9(index_top4,1),nodes9(index_top4,2),'k','LineWidth',1.8)
plot(nodes9(index_obl3,1),nodes9(index_obl3,2),'k','LineWidth',1.8)
plot(nodes9(index_top5,1),nodes9(index_top5,2),'k','LineWidth',1.8)
plot(nodes9(index_obl4,1),nodes9(index_obl4,2),'k','LineWidth',1.8)
plot(nodes9(index_top6,1),nodes9(index_top6,2),'k','LineWidth',1.8)
plot(nodes9(index_obl5,1),nodes9(index_obl5,2),'k','LineWidth',1.8)
pbaspect([3 1 1])


