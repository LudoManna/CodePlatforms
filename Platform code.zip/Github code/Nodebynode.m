function [sigma_xx,sigma_yy,sigma_xy,sigma1,sigma2,sigmavec1,sigmavec2,sigdiff,sigm]=Nodebynode(Sigma4_xx,Sigma4_yy,Sigma4_xy,nodes4,elems4)
sigma_xx=zeros(size(nodes4,1),1);
sigma_yy=zeros(size(nodes4,1),1);
sigma_xy=zeros(size(nodes4,1),1);
sigma1=zeros(size(nodes4,1),1);
sigma2=zeros(size(nodes4,1),1);
sigmavec1=zeros(size(nodes4,1),2);
sigmavec2=zeros(size(nodes4,1),2);
sigdiff=zeros(size(nodes4,1),1);
sigm=zeros(size(nodes4,1),1);





for i=1:size(nodes4,1)
   vec1=find(elems4(:,1)==i);
   vec2=find(elems4(:,2)==i);
   vec3=find(elems4(:,3)==i); 
   sigma_xx(i)=mean([Sigma4_xx(vec1,1);Sigma4_xx(vec2,2);Sigma4_xx(vec3,3)]);
   sigma_yy(i)=mean([Sigma4_yy(vec1,1);Sigma4_yy(vec2,2);Sigma4_yy(vec3,3)]);
   sigma_xy(i)=mean([Sigma4_xy(vec1,1);Sigma4_xy(vec2,2);Sigma4_xy(vec3,3)]); 
   
   sigma=[sigma_xx(i) sigma_xy(i);sigma_xy(i) sigma_yy(i)];
   
   [V,D]=eig(sigma);
   sigmavec1(i,:)=V(:,1)';
   sigmavec2(i,:)=V(:,2)';
   sigma1(i)=-D(1,1);
   sigma2(i)=-D(2,2);
   sigdiff(i)=sigma1(i)-sigma2(i);
   sigm(i)=(sigma1(i)+sigma2(i))/2;
   
   
   
end

end