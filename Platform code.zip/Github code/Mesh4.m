function [nodes6,elems6,mat_el6,mark6]=Mesh4(nodes5,TOPM3,OBLM3,HORM3,VER,PB1,nOBLM3,nHORM3,nTOPM3,elems4,nnod4);


% clearvars -except nodes3 TOP1M2 OBLM2 TOP2M2 A1 B1 nOBLM2 nTOP2M2 nTOP1M2 elems2 nnod2
% %% to erase
% clc
% clear
BAS=2000;
Bas=586.7;
bas=500;
H=300;
h=50;
% E1=10^7;
% nu1=0.4;
% rho1=0.22*10^4;
% E2=10^9;
% nu2=0.3;
rho2=0.271*10^4;
% %%
nu3=0.3;
E3=10^9;

n1=nTOPM3+nOBLM3+nHORM3;

%cont=[0,0; nodes1(RIGHT,:); nodes1(TOP1,:); nodes1(OBL,:); nodes1(TOP2,:)]';
points=[nodes5(TOPM3,:);nodes5(OBLM3,:);nodes5(HORM3,:);PB1;VER]';
markers=[ones(1,n1-1),5,1,1];
segments= [1:n1+2;2:n1+2 1];
opts.element_type     = 'tri3';
opts.min_angle        = 30;
opts.max_tri_area     = 3; %5
opts.gen_edges        = 1;
tristr.points         = points;
tristr.segments       = uint32(segments);
tristr.segmentmarkers = uint32(markers);
%tristr.regions        = [BAS/2,H/2,1,-1;(bas+Bas)/4,H+h/2,2,-1]';
%tristr.holes=[0,0]';
MESH = mtriangle(opts, tristr);
nodes6=MESH.NODES';
elems6=MESH.ELEMS';
nel6=size(elems6,1);
nodes6(1:n1,:)=[];
nodes6=[nodes5;nodes6];
mark6=[ones(length(nodes5)-n1,1);MESH.node_markers'];

prelem=elems6(:);
prov1=[1:n1];
prov2=[TOPM3',OBLM3',HORM3'];
    
for i=1:n1
    prelem(find(prelem(:,1)==prov1(i)))=prov2(i);
end
   
prelem(find(prelem(:,1)<min(prov2)))=prelem(find(prelem(:,1)<min(prov2)))+(nnod4-n1);

clear elems6

elems6=reshape(prelem,nel6,3);
    
% elems4=elems4+(nnod2-n1);
% prov1=[nnod2-n1+1:nnod2];
% prov2=[TOP1M2',OBLM2',TOP2M2'];
% 
% for i=1:n1
%     elems4(elems4==prov1(i))=prov2(i);
% end



mu1=E3/(2*(1+nu3));
    lambda1=nu3*E3/((1+nu3)*(1-2*nu3));
    mat_el6=[ones(size(elems6,1),1)*mu1,ones(size(elems6,1),1)*lambda1,ones(size(elems6,1),1)*rho2];
elems6=[elems4;elems6];

% mat_el2=zeros(size(elems,1),3);

% mat_el(find(MESH.elem_markers'==1),:)=repmat([mu1,lambda1,rho1],length(find(MESH.elem_markers'==1)),1);
% mat_el(find(MESH.elem_markers'==2),:)=repmat([mu2,lambda2,rho2],length(find(MESH.elem_markers'==2)),1);



end  