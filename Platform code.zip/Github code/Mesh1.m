function [nodes,elems,mat_el]= Mesh1(BAS,Bas,bas,H,h,E1,nu1,rho1,E2,nu2,rho2)

cont=[0,0; BAS,0;BAS,H;Bas,H;0,H;0,H+h;bas,H+h]';
points=[cont];
segments_rec=[1,2,3,4,5; 2,3,4,5,1];
segments_trap=[5,4,7,6;4,7,6,5];
segments= [segments_rec,segments_trap];
opts.element_type     = 'tri3';
opts.min_angle        = 30;
opts.max_tri_area     = 3; %5
opts.gen_edges        =1;
tristr.points         = points;
tristr.segments       = uint32(segments);
tristr.regions        = [BAS/2,H/2,1,-1;(bas+Bas)/4,H+h/2,2,-1]';
%tristr.holes=[0,0]';
MESH = mtriangle(opts, tristr);
nodes=MESH.NODES';
elems=MESH.ELEMS';
mat_el=zeros(size(elems,1),3);
mu1=E1/(2*(1+nu1));
    lambda1=nu1*E1/((1+nu1)*(1-2*nu1));
    mu2=E2/(2*(1+nu2));
    lambda2=nu2*E2/((1+nu2)*(1-2*nu2));
mat_el(find(MESH.elem_markers'==1),:)=repmat([mu1,lambda1,rho1],length(find(MESH.elem_markers'==1)),1);
mat_el(find(MESH.elem_markers'==2),:)=repmat([mu2,lambda2,rho2],length(find(MESH.elem_markers'==2)),1);



end  