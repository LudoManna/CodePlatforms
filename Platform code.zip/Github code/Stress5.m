function Sigma8 = Stress5(nodes8,elems8,mat_el8,uh8,uv)

%% inputs
[nnod8,ndim]=size(nodes8);
[nel8,nnodel]=size(elems8);
ndofel=ndim*nnodel;

%% displacements
uhx8=uh8(1:2:(2*nnod8-1));
uhy8=uh8(2:2:2*nnod8);
%% stress points
npts=size(uv,2);
dNdu = zeros(ndim,nnodel,npts);
Sigma8=zeros(nel8,3,npts);

%% shape function derivatives
U=uv(1,:);
V=uv(2,:);
for ipts=1:npts %ip
        dNdu(1,1,ipts) = -1;  
        dNdu(1,2,ipts) =  1;
        dNdu(1,3,ipts) =  0;
        dNdu(2,1,ipts) = -1;  
        dNdu(2,2,ipts) =  0;
        dNdu(2,3,ipts) =  1;
    
end

%% element loop
for iel=1:nel8
    index_el=elems8(iel,:);
    nodes_el = nodes8(elems8(iel,:),:);
    B_el = zeros(3,ndofel);  
    mu=mat_el8(iel,1);
    lambda=mat_el8(iel,2);
    rho=mat_el8(iel,3);
    D=[2*mu+lambda, lambda, 0; lambda, 2*mu+lambda, 0; 0, 0, mu];
    u_el8=[uhx8(index_el(1));uhy8(index_el(1));uhx8(index_el(2));uhy8(index_el(2));uhx8(index_el(3));uhy8(index_el(3))]; %change it, less explicit, not uhx and uhy but indexes
    for ipts=1:npts
        dxdu=dNdu(:,:,ipts)*nodes_el;
        dudx = inv(dxdu);
        Jac = det(dxdu); 
        dNdx = dudx*dNdu(:,:,ipts);
        B_el([1,3],1:ndim:end-1) = dNdx; 
        B_el([3,2],2:ndim:end) = dNdx;
    Sigma8(iel,:,ipts)=D*B_el*u_el8;
    end
    
end