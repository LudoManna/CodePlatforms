function Sigma2 = Stress2(nodes2,elems2,mat_el2,uh2,uv)


%% inputs
[nnod2,ndim]=size(nodes2);
[nel2,nnodel]=size(elems2);
ndofel=ndim*nnodel;

%% displacements
uhx2=uh2(1:2:(2*nnod2-1));
uhy2=uh2(2:2:2*nnod2);
%% stress points
npts=size(uv,2);
dNdu = zeros(ndim,nnodel,npts);
Sigma2=zeros(nel2,3,npts);

%% shape function derivatives
U=uv(1,:);
V=uv(2,:);
for ipts=1:npts %ip
        dNdu(1,1,ipts) = -1;  
        dNdu(1,2,ipts) =  1;
        dNdu(1,3,ipts) =  0;
        dNdu(2,1,ipts) = -1;  
        dNdu(2,2,ipts) =  0;
        dNdu(2,3,ipts) =  1;
    
end

%% element loop
for iel=1:nel2
    index_el=elems2(iel,:);
    nodes_el = nodes2(elems2(iel,:),:);
    B_el = zeros(3,ndofel);  
    mu=mat_el2(iel,1);
    lambda=mat_el2(iel,2);
    rho=mat_el2(iel,3);
    D=[2*mu+lambda, lambda, 0; lambda, 2*mu+lambda, 0; 0, 0, mu];
    u_el2=[uhx2(index_el(1));uhy2(index_el(1));uhx2(index_el(2));uhy2(index_el(2));uhx2(index_el(3));uhy2(index_el(3))]; %change it, less explicit, not uhx and uhy but indexes
    for ipts=1:npts
        dxdu=dNdu(:,:,ipts)*nodes_el;
        dudx = inv(dxdu);
        Jac = det(dxdu); 
        dNdx = dudx*dNdu(:,:,ipts);
        B_el([1,3],1:ndim:end-1) = dNdx; 
        B_el([3,2],2:ndim:end) = dNdx;
    Sigma2(iel,:,ipts)=D*B_el*u_el2;
    end
    
end