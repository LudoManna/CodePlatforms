%Code for the solution of differential compaction problems. 
clc
clear

%% inputs
BAS=2000;  %Length of the basin
bas=500;   %Smaller base of the first sediment
fi=pi/6;   %Slope angle
H=300;     %Height of the basin
h=50;      %Height of the first sediment platform
slength= h/sin(fi); %Length of the slope of the first sediment
Bas=slength*cos(fi)+bas; %Larger base of the first sediment
E1=10^8;   %Young modulus of the basin
nu1=0.15;  %Poisson ratio of the basin
rho1=0.22*10^4;           %density of the basin
E2=10^9;                  %young modulus of the non-early lithified platform
nu2=0.3;                  %poisson ratio of the sediments
rho2=0.271*10^4;          %density of the sediments
theta=atan(h/(Bas-bas));  %slope of the sediment

%% first unstructured mesh
tic
[nodes,elems,mat_el]= Mesh1(BAS,Bas,bas,H,h,E1,nu1,rho1,E2,nu2,rho2);
%nodes contains the coordinates of the nodal points, elems the indexes of
%the nodes of each element, mat_el has the lamè constants mu and lambda of each element
%in the first two columns and the density in the third
%in order to produce the mesh, the Triangle mesh generator by J.R.
%Shewchuk must be downloaded and installed.

[nnod,ndim]=size(nodes); %number of nodes and dimensions of the model
[nel,nnodel]=size(elems); %number of elements and umber of nodes for each element
ndofel=ndim*nnodel; %number of degrees of freedom for each element
index_bottom=find(nodes(:,2)==0); %indexes of nodes located at the 
                                  %base of the basin
index_left=find(nodes(:,1)==0); %indexes of nodes located on the left side
                                  %of the domain
nbot=length(index_bottom);
nleft=length(index_left);  

index_top=find(nodes(:,2)==H+h & nodes(:,1)<=bas); %indexes of nodes located
                                  %on the top side of the first platform
index_right=find(nodes(:,1)==BAS); %indexes of nodes located at the right 
                                   %side of the basin
ntop=length(index_top);
nright=length(index_right);

display(['Unstructured mesh: ',num2str(toc)])
index_tob=find(nodes(:,2)==H & nodes(:,1)>=Bas); %indexes of nodes located 
                                  % at the free top surface of the basin
ntob=length(index_tob);
epsilon=0.8;
index_obl=find(nodes(:,2)<=nodes(:,1)*((nodes(4,2)-nodes(7,2))/(nodes(4,1)- ...
    nodes(7,1)))+nodes(7,2)-nodes(7,1)*((nodes(4,2)-nodes(7,2))/(nodes(4,1) ...
    -nodes(7,1)))+epsilon & nodes(:,2)>=nodes(:,1)*((nodes(4,2)-nodes(7,2)) ...
    /(nodes(4,1)-nodes(7,1)))+nodes(7,2)-nodes(7,1)*((nodes(4,2)-nodes(7,2)) ...
    /(nodes(4,1)-nodes(7,1)))-epsilon & nodes(:,2)>H); %indexes of nodes on
                                                       %the platform slope
nobl=length(index_obl);

OBL=sortrows([nodes(index_obl,1),index_obl]);
OBL=OBL(:,2);
OBL(1)=[];
nOBL=length(OBL);
TOP2=sortrows([nodes(index_top,1),index_top]);
TOP2=TOP2(:,2);
nTOP2=length(TOP2);

%% constant body forces
bx=0; 
by=0;

%% FEM stress matrix and external force computation
tic
[K,f] = Stiff1(nodes,elems,mat_el,bx,by); %K stiffness matrix, f force vector
                                          %these matrices contain the
                                          %elementary stiffness matrix and
                                          %force vector of each element,
                                          %and they have to be assembled
display(['Stiffness matrix: ',num2str(toc)]) 

%% assembly
tic
index_gl = 2*double(elems(:,[1,1,2,2,3,3]))...
          -[1,0,1,0,1,0]; %global index
index_gl=index_gl';
I=repmat(index_gl,ndofel,1);
J=reshape(repmat(index_gl(:)',ndofel,1),ndofel^2,[]);
k_gl=sparse(I,J,K); %global stiffness matrix assembly
ELMS=zeros(1,6*nel); %occhio
elems=elems';
ELMS(2:2:end)=2*elems(:)';
ELMS(1:2:end-1)=2*elems(:)'-1;
f_gl=accumarray(ELMS',f(:)); %global force vector assembly
elems=elems';
display(['Assembly: ',num2str(toc)])

 %% neumann bc

%% dirichlet boundary conditions
tic
k_gl(2*index_bottom,:)=zeros(nbot,ndim*nnod);
k_gl(2*index_bottom,2*index_bottom)=eye(nbot);
f_gl(2*index_bottom)=0; %horizontal roller bcs for the bottom side nodes
k_gl(2*index_left-1,:)=zeros(nleft,ndim*nnod);
k_gl(2*index_left-1,2*index_left-1)=eye(nleft);
f_gl(2*index_left-1)=0; %vertical roller bcs for the left side nodes
% k_gl(2*index_right-1,:)=zeros(nright,ndim*nnod);
% k_gl(2*index_right-1,2*index_right-1)=eye(nright);
% f_gl(2*index_right-1)=0; %vertical roller bcs for the right side nodes
display(['Dirichlet bcs: ',num2str(toc)])

%% displacement computation
tic
uh=k_gl\f_gl; %displacements computation
uh=full(uh); 
display(['Displacement computation: ',num2str(toc)])
uhx=uh(1:ndim:(2*nnod-1)); %horizontal displacements of the nodes
uhy=uh(2:ndim:2*nnod); %vertical displacements of the nodes
X=nodes(:,1);
Y=nodes(:,2);

%% stress tensor element by element
tic
uv=[0 0; 1 0; 0 1]';
Sigma = Stress1(nodes,elems,mat_el,uh,uv); %element by element stress computation
Sigma=permute(Sigma,[1 3 2]);
Sigma_xx=Sigma(:,:,1); %xx component of the stress tensor, for each element
                       %calculated on the three nodes
Sigma_yy=Sigma(:,:,2); %same witht the yy component
Sigma_xy=Sigma(:,:,3); %xy component
display(['Stress tensor: ',num2str(toc)])

%% second mesh

nodes1=[nodes(:,1)+uhx,nodes(:,2)+uhy]; %modified geometry of the system after
                                        %the first compaction
corner=7;
mat_el(find(mat_el(:,1)>10^8),[1,2])=10*mat_el(find(mat_el(:,1)>10^8),[1,2]); %redo
mat_el(:,3)=zeros(nel,1);
%The compacted sediments have different Young modulus and all the system
%has zero density because it is in mechanical equilibrium, and further
%compaction is modeled as effect of the subsequent stages of platform
%growth
Agg=50; %aggradation of the platform
Progr=0; %progradation of the platform (PA ratio=0)
B=nodes1(corner,:)+[Progr,Agg]; % prograding and agrading
A=[0,B(2)];
corner1=4;
h1=B(2)-nodes1(corner1,2);
C=B(1)+h1*cot(theta);
index_top3=index_tob(find(nodes1(index_tob,1)>=nodes1(corner1,1) & nodes1(index_tob,1)<=C));
TOP3=sortrows([nodes1(index_top3,1),index_top3]);
TOP3=TOP3(:,2);
nTOP3=length(TOP3);

[nodes2,elems2,mat_el2]=Mesh2(nodes1,TOP2,OBL,TOP3,A,B,nOBL,nTOP2,nTOP3,elems,nnod);
mat_el2=[mat_el;mat_el2];
[nnod2,ndim]=size(nodes2);
[nel2,nnodel]=size(elems2);
ndofel=ndim*nnodel;
index_bottom2=find(nodes2(:,2)==0);
index_left2=find(nodes2(:,1)==0);
nbot2=length(index_bottom2);
nleft2=length(index_left2);  
index_top1m2=find(nodes2(:,2)==max(nodes2(:,2)));
TOP1M2=sortrows([nodes2(index_top1m2,1),index_top1m2]);
TOP1M2=TOP1M2(:,2);
nTOP1M2=length(TOP1M2);

%% FEM stress matrix and external force computation
tic
[K2,f2] = Stiff2(nodes2,elems2,mat_el2,bx,by);
display(['Stiffness matrix: ',num2str(toc)])

%% assembly
tic
index_gl = 2*double(elems2(:,[1,1,2,2,3,3]))...
          -[1,0,1,0,1,0];
index_gl=index_gl';
I=repmat(index_gl,ndofel,1);
J=reshape(repmat(index_gl(:)',ndofel,1),ndofel^2,[]);
k_gl2=sparse(I,J,K2);
ELMS2=zeros(1,6*nel2);
elems2=elems2';
ELMS2(2:2:end)=2*elems2(:)';
ELMS2(1:2:end-1)=2*elems2(:)'-1;
f_gl2=accumarray(ELMS2',f2(:));
elems2=elems2';
display(['Assembly: ',num2str(toc)])

%% dirichlet boundary conditions
tic
k_gl2(2*index_bottom2,:)=zeros(nbot2,ndim*nnod2);
k_gl2(2*index_bottom2,2*index_bottom2)=eye(nbot2);
f_gl2(2*index_bottom2)=0;
k_gl2(2*index_left2-1,:)=zeros(nleft2,ndim*nnod2);
k_gl2(2*index_left2-1,2*index_left2-1)=eye(nleft2);
f_gl2(2*index_left2-1)=0;
% k_gl(2*index_right-1,:)=zeros(nright,ndim*nnod);
% k_gl(2*index_right-1,2*index_right-1)=eye(nright);
% f_gl(2*index_right-1)=0;
display(['Dirichlet bcs: ',num2str(toc)])

%% displacement computation
tic
uh2=k_gl2\f_gl2; 
uh2=full(uh2); 
display(['Displacement computation: ',num2str(toc)])
uhx2=uh2(1:ndim:(2*nnod2-1));
uhy2=uh2(2:ndim:2*nnod2);

%% stress tensor element by element
tic
uv=[0 0; 1 0; 0 1]';
Sigma2 = Stress2(nodes2,elems2,mat_el2,uh2,uv);
Sigma2=permute(Sigma2,[1 3 2]);
Sigma2(1:nel,:,:)=Sigma2(1:nel,:,:)+Sigma;
Sigma2_xx=Sigma2(:,:,1);
Sigma2_yy=Sigma2(:,:,2);
Sigma2_xy=Sigma2(:,:,3);
display(['Stress tensor: ',num2str(toc)])

nodes3=[nodes2(:,1)+uhx2,nodes2(:,2)+uhy2];
xcornernod2=reshape(nodes3(elems2(:,1:3),1),nel2,3)';
ycornernod2=reshape(nodes3(elems2(:,1:3),2),nel2,3)';
numbering_array2=reshape(1:3*nel2,3,nel2)';
a=(nodes2(TOP3(end),2)-nodes2(nnod+1,2))/(nodes2(TOP3(end),1)-nodes2(nnod+1,1));
b=nodes2(nnod+1,2)-a*nodes2(nnod+1,1);
index_oblm2=find(nodes2(:,2)<= a*nodes2(:,1)+b+epsilon & nodes2(:,2)>= a*nodes2(:,1)+b-epsilon & nodes3(:,2) >= nodes3(TOP3(end),2));
OBLM2=sortrows([nodes2(index_oblm2,1),index_oblm2]);
OBLM2=OBLM2(:,2);
OBLM2(1)=[];
nOBLM2=length(OBLM2);
B1=[nodes3(TOP1M2(end),1)+Progr,nodes3(TOP1M2(end),2)+Agg];
A1=[0,B1(2)];
h2=B1(2)-nodes3(OBLM2(end),2);
C1=B1(1)+h2*cot(fi);
index_top2m2=index_tob(find(nodes3(index_tob,1)>nodes3(OBLM2(end),1) & nodes3(index_tob,1)<=C1));
TOP2M2=sortrows([nodes1(index_top2m2,1),index_top2m2]);
TOP2M2=TOP2M2(:,2);
nTOP2M2=length(TOP2M2);
mat_el2(find(mat_el2(:,1) >10^8 & mat_el2(:,1) <10^9),:)=10*mat_el2(find(mat_el2(:,1) >10^8 & mat_el2(:,1) <10^9),:);
mat_el2(:,3)=0*mat_el2(:,3);

[nodes4,elems4,mat_el4]=Mesh3(nodes3,TOP1M2,OBLM2,TOP2M2,A1,B1,nOBLM2,nTOP2M2,nTOP1M2,elems2,nnod2);
mat_el4=[mat_el2;mat_el4];
[nnod4,ndim]=size(nodes4);
[nel4,nnodel]=size(elems4);
ndofel=ndim*nnodel;
index_bottom4=find(nodes4(:,2)==0);
index_left4=find(nodes4(:,1)==0);
nbot4=length(index_bottom4);
nleft4=length(index_left4);

%% FEM stress matrix and external force computation
tic
[K4,f4] = Stiff3(nodes4,elems4,mat_el4,bx,by);
display(['Stiffness matrix: ',num2str(toc)]) 

%% assembly
tic
index_gl = 2*double(elems4(:,[1,1,2,2,3,3]))...
          -[1,0,1,0,1,0];
index_gl=index_gl';
I=repmat(index_gl,ndofel,1);
J=reshape(repmat(index_gl(:)',ndofel,1),ndofel^2,[]);
k_gl4=sparse(I,J,K4);
ELMS4=zeros(1,6*nel4);
elems4=elems4';
ELMS4(2:2:end)=2*elems4(:)';
ELMS4(1:2:end-1)=2*elems4(:)'-1;
f_gl4=accumarray(ELMS4',f4(:));
elems4=elems4';
display(['Assembly: ',num2str(toc)])

%% dirichlet boundary conditions
tic
k_gl4(2*index_bottom4,:)=zeros(nbot4,ndim*nnod4);
k_gl4(2*index_bottom4,2*index_bottom4)=eye(nbot4);
f_gl4(2*index_bottom4)=0;
k_gl4(2*index_left4-1,:)=zeros(nleft4,ndim*nnod4);
k_gl4(2*index_left4-1,2*index_left4-1)=eye(nleft4);
f_gl4(2*index_left4-1)=0;
% k_gl(2*index_right-1,:)=zeros(nright,ndim*nnod);
% k_gl(2*index_right-1,2*index_right-1)=eye(nright);
% f_gl(2*index_right-1)=0;
display(['Dirichlet bcs: ',num2str(toc)])

%% displacement computation
tic
uh4=k_gl4\f_gl4; 
uh4=full(uh4); 
display(['Displacement computation: ',num2str(toc)])
uhx4=uh4(1:ndim:(2*nnod4-1));
uhy4=uh4(2:ndim:2*nnod4);
u4=sqrt(uhx4.^2+uhy4.^2); 
%% stress tensor element by element
tic
uv=[0 0; 1 0; 0 1]';
Sigma4 = Stress3(nodes4,elems4,mat_el4,uh4,uv);
Sigma4=permute(Sigma4,[1 3 2]);
Sigma4(1:nel2,:,:)=Sigma4(1:nel2,:,:)+Sigma2;
Sigma4_xx=Sigma4(:,:,1);
Sigma4_yy=Sigma4(:,:,2);
Sigma4_xy=Sigma4(:,:,3);
Sigma1=0.5*(-(Sigma4_xx+Sigma4_yy)+sqrt((Sigma4_xx+Sigma4_yy).^2-4*(Sigma4_xx.*Sigma4_yy-Sigma4_xy.^2)));
Sigma_diff=sqrt((Sigma4_xx+Sigma4_yy).^2-4*(Sigma4_xx.*Sigma4_yy-Sigma4_xy.^2));
Sigma3=Sigma1-Sigma_diff;
Sigma_m=(Sigma1+Sigma3)/2;
display(['Stress tensor: ',num2str(toc)])
nodes5=[nodes4(:,1)+uhx4,nodes4(:,2)+uhy4];
xcornernod4=reshape(nodes5(elems4(:,1:3),1),nel4,3)';
ycornernod4=reshape(nodes5(elems4(:,1:3),2),nel4,3)';
numbering_array4=reshape(1:3*nel4,3,nel4)';

Sig_diff=(1/3)*(Sigma_diff(:,1)+Sigma_diff(:,2)+Sigma_diff(:,3));
Sig_1=(1/3)*(Sigma1(:,1)+Sigma1(:,2)+Sigma1(:,3));
Sig_3=(1/3)*(Sigma3(:,1)+Sigma3(:,2)+Sigma3(:,3));
Sig_m=(1/3)*(Sigma_m(:,1)+Sigma_m(:,2)+Sigma_m(:,3));

%% Stresses node by node

epsilon1=0.1;

TOPM3=find(nodes4(:,2)<=B1(2)+epsilon & nodes4(:,2)>=B1(2)-epsilon);
TOPM3=sortrows([nodes5(TOPM3,1),TOPM3]);
TOPM3(:,1)=[];
nTOPM3=length(TOPM3);

OBLM3=find(nodes4(:,2)<=-tan(fi)*nodes4(:,1)+B1(2)+tan(fi)*B1(1)+epsilon1 ...
    & nodes4(:,2)>=-tan(fi)*nodes4(:,1)+B1(2)+tan(fi)*B1(1)-epsilon1 & ...
    nodes4(:,2)>= nodes4(TOP2M2(end),2)-epsilon1);

OBLM3=sortrows([nodes5(OBLM3,1),OBLM3]);
OBLM3(:,1)=[];
OBLM3(1)=[];
nOBLM3=length(OBLM3);

PB_ind=TOPM3(end);
PB1=nodes5(PB_ind,:)+[Progr,Agg];
VER=[0,PB1(2)];
h3=PB1(2)-nodes5(OBLM3(end),2);
C2=PB1(1)+h3*cot(fi);

index_horm3=index_tob(find(nodes5(index_tob,1)>nodes5(OBLM3(end),1) & nodes5(index_tob,1)<=C2));
HORM3=sortrows([nodes1(index_horm3,1),index_horm3]);
HORM3=HORM3(:,2);
nHORM3=length(HORM3);

mat_el4(find(mat_el4(:,1) >10^8 & mat_el4(:,1) <10^9),:)=10*mat_el4(find(mat_el4(:,1) >10^8 & mat_el4(:,1) <10^9),:);
mat_el4(:,3)=0*mat_el4(:,3);

%% meshing

[nodes6,elems6,mat_el6,mark6]=Mesh4(nodes5,TOPM3,OBLM3,HORM3,VER,PB1,nOBLM3,nHORM3,nTOPM3,elems4,nnod4);
mat_el6=[mat_el4;mat_el6];
[nnod6,ndim]=size(nodes6);
[nel6,nnodel]=size(elems6);
ndofel=ndim*nnodel;
index_bottom6=find(nodes6(:,2)==0);
index_left6=find(nodes6(:,1)==0);
nbot6=length(index_bottom6);
nleft6=length(index_left6);

%% FEM stress matrix and external force computation
tic
[K6,f6] = Stiff4(nodes6,elems6,mat_el6,bx,by);
display(['Stiffness matrix: ',num2str(toc)])

%% assembly
tic
index_gl = 2*double(elems6(:,[1,1,2,2,3,3]))...
          -[1,0,1,0,1,0];
index_gl=index_gl';
I=repmat(index_gl,ndofel,1);
J=reshape(repmat(index_gl(:)',ndofel,1),ndofel^2,[]);
k_gl6=sparse(I,J,K6);
ELMS6=zeros(1,6*nel6);
elems6=elems6';
ELMS6(2:2:end)=2*elems6(:)';
ELMS6(1:2:end-1)=2*elems6(:)'-1;
f_gl6=accumarray(ELMS6',f6(:));
elems6=elems6';
display(['Assembly: ',num2str(toc)])

%% dirichlet boundary conditions
tic
k_gl6(2*index_bottom6,:)=zeros(nbot6,ndim*nnod6);
k_gl6(2*index_bottom6,2*index_bottom6)=eye(nbot6);
f_gl6(2*index_bottom6)=0;
k_gl6(2*index_left6-1,:)=zeros(nleft6,ndim*nnod6);
k_gl6(2*index_left6-1,2*index_left6-1)=eye(nleft6);
f_gl6(2*index_left6-1)=0;
% k_gl(2*index_right-1,:)=zeros(nright,ndim*nnod);
% k_gl(2*index_right-1,2*index_right-1)=eye(nright);
% f_gl(2*index_right-1)=0;
display(['Dirichlet bcs: ',num2str(toc)])

%% displacement computation
tic
uh6=k_gl6\f_gl6; 
uh6=full(uh6);
display(['Displacement computation: ',num2str(toc)])
uhx6=uh6(1:ndim:(2*nnod6-1));
uhy6=uh6(2:ndim:2*nnod6);
u6=sqrt(uhx6.^2+uhy6.^2);

%% stress tensor element by element
tic
uv=[0 0; 1 0; 0 1]';
Sigma6 = Stress4(nodes6,elems6,mat_el6,uh6,uv);
Sigma6=permute(Sigma6,[1 3 2]);
Sigma6(1:nel4,:,:)=Sigma6(1:nel4,:,:)+Sigma4;
Sigma6_xx=Sigma6(:,:,1);
Sigma6_yy=Sigma6(:,:,2);
Sigma6_xy=Sigma6(:,:,3);
Sigma1=0.5*(-(Sigma6_xx+Sigma6_yy)+sqrt((Sigma6_xx+Sigma6_yy).^2-4*(Sigma6_xx.*Sigma6_yy-Sigma6_xy.^2)));
Sigma_diff=sqrt((Sigma6_xx+Sigma6_yy).^2-4*(Sigma6_xx.*Sigma6_yy-Sigma6_xy.^2));
Sigma3=Sigma1-Sigma_diff;
Sigma_m=(Sigma1+Sigma3)/2;
display(['Stress tensor: ',num2str(toc)])
nodes7=[nodes6(:,1)+uhx6,nodes6(:,2)+uhy6];
xcornernod6=reshape(nodes7(elems6(:,1:3),1),nel6,3)';
ycornernod6=reshape(nodes7(elems6(:,1:3),2),nel6,3)';
numbering_array6=reshape(1:3*nel6,3,nel6)';

Sig_diff=(1/3)*(Sigma_diff(:,1)+Sigma_diff(:,2)+Sigma_diff(:,3));
Sig_1=(1/3)*(Sigma1(:,1)+Sigma1(:,2)+Sigma1(:,3));
Sig_3=(1/3)*(Sigma3(:,1)+Sigma3(:,2)+Sigma3(:,3));
Sig_m=(1/3)*(Sigma_m(:,1)+Sigma_m(:,2)+Sigma_m(:,3));

%% fourth mesh

epsilon1=0.1;

TOPM4=find(nodes6(:,2)<=PB1(2)+epsilon & nodes6(:,2)>=PB1(2)-epsilon);
TOPM4=sortrows([nodes7(TOPM4,1),TOPM4]);
TOPM4(:,1)=[];
nTOPM4=length(TOPM4);
OBLM4=find(mark6(:,1)==5);
OBLM4=sortrows([nodes7(OBLM4,1),OBLM4]);
OBLM4(:,1)=[];
OBLM4(1)=[];
nOBLM4=length(OBLM4);


PB2_ind=TOPM4(end);
PB2=nodes7(PB2_ind,:)+[Progr,Agg];
VER2=[0,PB2(2)];
h4=PB2(2)-nodes7(OBLM4(end),2);
C3=PB2(1)+h4*cot(fi);

index_horm4=index_tob(find(nodes7(index_tob,1)>nodes7(OBLM4(end),1) & nodes7(index_tob,1)<=C3));
HORM4=sortrows([nodes1(index_horm4,1),index_horm4]);
HORM4=HORM4(:,2);
HORM4(1)=[];
nHORM4=length(HORM4);

mat_el6(find(mat_el6(:,1) >10^8 & mat_el6(:,1) <10^9),:)=10*mat_el6(find(mat_el6(:,1) >10^8 & mat_el6(:,1) <10^9),:);
mat_el6(:,3)=0*mat_el6(:,3);

%% meshing

[nodes8,elems8,mat_el8]=Mesh5(nodes7,TOPM4,OBLM4,HORM4,VER2,PB2,nOBLM4,nHORM4,nTOPM4,elems6,nnod6);
mat_el8=[mat_el6;mat_el8];
[nnod8,ndim]=size(nodes8);
[nel8,nnodel]=size(elems8);
ndofel=ndim*nnodel;
index_bottom8=find(nodes8(:,2)==0);
index_left8=find(nodes8(:,1)==0);
nbot8=length(index_bottom8);
nleft8=length(index_left8);

%% FEM stress matrix and external force computation
tic
[K8,f8] = Stiff5(nodes8,elems8,mat_el8,bx,by);
display(['Stiffness matrix: ',num2str(toc)])
%% assembly
tic
index_gl = 2*double(elems8(:,[1,1,2,2,3,3]))...
          -[1,0,1,0,1,0];
index_gl=index_gl';
I=repmat(index_gl,ndofel,1);
J=reshape(repmat(index_gl(:)',ndofel,1),ndofel^2,[]);
k_gl8=sparse(I,J,K8);
ELMS8=zeros(1,6*nel8);
elems8=elems8';
ELMS8(2:2:end)=2*elems8(:)';
ELMS8(1:2:end-1)=2*elems8(:)'-1;
f_gl8=accumarray(ELMS8',f8(:));
elems8=elems8';
display(['Assembly: ',num2str(toc)])

%% dirichlet boundary conditions
tic
k_gl8(2*index_bottom8,:)=zeros(nbot8,ndim*nnod8);
k_gl8(2*index_bottom8,2*index_bottom8)=eye(nbot8);
f_gl8(2*index_bottom8)=0;
k_gl8(2*index_left8-1,:)=zeros(nleft8,ndim*nnod8);
k_gl8(2*index_left8-1,2*index_left8-1)=eye(nleft8);
f_gl8(2*index_left8-1)=0;
% k_gl(2*index_right-1,:)=zeros(nright,ndim*nnod);
% k_gl(2*index_right-1,2*index_right-1)=eye(nright);
% f_gl(2*index_right-1)=0;
display(['Dirichlet bcs: ',num2str(toc)])

%% displacement computation
tic
uh8=k_gl8\f_gl8; 
uh8=full(uh8);
display(['Displacement computation: ',num2str(toc)])
uhx8=uh8(1:ndim:(2*nnod8-1));
uhy8=uh8(2:ndim:2*nnod8);
u8=sqrt(uhx8.^2+uhy8.^2);
%% stress tensor element by element
tic
uv=[0 0; 1 0; 0 1]';
Sigma8 = Stress5(nodes8,elems8,mat_el8,uh8,uv);
Sigma8=permute(Sigma8,[1 3 2]);
Sigma8(1:nel6,:,:)=Sigma8(1:nel6,:,:)+Sigma6;
Sigma8_xx=Sigma8(:,:,1);
Sigma8_yy=Sigma8(:,:,2);
Sigma8_xy=Sigma8(:,:,3);
Sigma1=0.5*(-(Sigma8_xx+Sigma8_yy)+sqrt((Sigma8_xx+Sigma8_yy).^2-4*(Sigma8_xx.*Sigma8_yy-Sigma8_xy.^2)));
Sigma_diff=sqrt((Sigma8_xx+Sigma8_yy).^2-4*(Sigma8_xx.*Sigma8_yy-Sigma8_xy.^2));
Sigma3=Sigma1-Sigma_diff;
Sigma_m=(Sigma1+Sigma3)/2;
display(['Stress tensor: ',num2str(toc)])
nodes9=[nodes8(:,1)+uhx8,nodes8(:,2)+uhy8];
xcornernod8=reshape(nodes9(elems8(:,1:3),1),nel8,3)';
ycornernod8=reshape(nodes9(elems8(:,1:3),2),nel8,3)';
numbering_array8=reshape(1:3*nel8,3,nel8)';

Sig_diff=(1/3)*(Sigma_diff(:,1)+Sigma_diff(:,2)+Sigma_diff(:,3));
Sig_1=(1/3)*(Sigma1(:,1)+Sigma1(:,2)+Sigma1(:,3));
Sig_3=(1/3)*(Sigma3(:,1)+Sigma3(:,2)+Sigma3(:,3));
Sig_m=(1/3)*(Sigma_m(:,1)+Sigma_m(:,2)+Sigma_m(:,3));


%% nodebynode
tic

[sigma_xx,sigma_yy,sigma_xy,sigma1,sigma2,sigmavec1,sigmavec2,sigdiff,sigm]=Nodebynode(Sigma8_xx,Sigma8_yy,Sigma8_xy,nodes8,elems8);
display(['Nodebynode: ',num2str(toc)]) %stresses calculated on the nodal points


critic=find(sigdiff(:)>3*max(sigdiff)/6 & sigm(:)<0);

filename='Tr5plPA0.mat'; %5 platforms, PA=0
% save(filename);

