function [nodes8,elems8,mat_el8]=Mesh5(nodes7,TOPM4,OBLM4,HORM4,VER2,PB2,nOBLM4,nHORM4,nTOPM4,elems6,nnod6);


% clearvars -except nodes3 TOP1M2 OBLM2 TOP2M2 A1 B1 nOBLM2 nTOP2M2 nTOP1M2 elems2 nnod2
% %% to erase
% clc
% clear
BAS=2000;
Bas=586.7;
bas=500;
H=300;
h=50;
% E1=10^7;
% nu1=0.4;
% rho1=0.22*10^4;
% E2=10^9;
% nu2=0.3;
rho2=0.271*10^4;
% %%
nu3=0.3;
E3=10^9;

n1=nTOPM4+nOBLM4+nHORM4;

%cont=[0,0; nodes1(RIGHT,:); nodes1(TOP1,:); nodes1(OBL,:); nodes1(TOP2,:)]';
points=[nodes7(TOPM4,:);nodes7(OBLM4,:);nodes7(HORM4,:);PB2;VER2]';
markers=[ones(1,n1-1),7,1,1];
segments= [1:n1+2;2:n1+2 1];
opts.element_type     = 'tri3';
opts.min_angle        = 30;
opts.max_tri_area     = 3; %5
opts.gen_edges        = 1;
tristr.points         = points;
tristr.segments       = uint32(segments);
tristr.segmentmarkers = uint32(markers);
%tristr.regions        = [BAS/2,H/2,1,-1;(bas+Bas)/4,H+h/2,2,-1]';
%tristr.holes=[0,0]';
MESH = mtriangle(opts, tristr);
nodes8=MESH.NODES';
elems8=MESH.ELEMS';
nel8=size(elems8,1);
nodes8(1:n1,:)=[];
nodes8=[nodes7;nodes8];
mark8=[ones(length(nodes7)-n1,1);MESH.node_markers'];

prelem=elems8(:);
prov1=[1:n1];
prov2=[TOPM4',OBLM4',HORM4'];
    
for i=1:n1
    prelem(find(prelem(:,1)==prov1(i)))=prov2(i);
end
   
prelem(find(prelem(:,1)<min(prov2)))=prelem(find(prelem(:,1)<min(prov2)))+(nnod6-n1);

clear elems8

elems8=reshape(prelem,nel8,3);
    
% elems4=elems4+(nnod2-n1);
% prov1=[nnod2-n1+1:nnod2];
% prov2=[TOP1M2',OBLM2',TOP2M2'];
% 
% for i=1:n1
%     elems4(elems4==prov1(i))=prov2(i);
% end



mu1=E3/(2*(1+nu3));
    lambda1=nu3*E3/((1+nu3)*(1-2*nu3));
    mat_el8=[ones(size(elems8,1),1)*mu1,ones(size(elems8,1),1)*lambda1,ones(size(elems8,1),1)*rho2];
elems8=[elems6;elems8];

% mat_el2=zeros(size(elems,1),3);

% mat_el(find(MESH.elem_markers'==1),:)=repmat([mu1,lambda1,rho1],length(find(MESH.elem_markers'==1)),1);
% mat_el(find(MESH.elem_markers'==2),:)=repmat([mu2,lambda2,rho2],length(find(MESH.elem_markers'==2)),1);



end  