function Sigma = Stress1(nodes,elems,mat_el,uh,uv)


%% inputs
[nnod,ndim]=size(nodes);
[nel,nnodel]=size(elems);
ndofel=ndim*nnodel;

%% displacements
uhx=uh(1:2:(2*nnod-1));
uhy=uh(2:2:2*nnod);
%% stress points
npts=size(uv,2);
dNdu = zeros(ndim,nnodel,npts);
Sigma=zeros(nel,3,npts);

%% shape function derivatives
U=uv(1,:);
V=uv(2,:);
for ipts=1:npts %ip
        dNdu(1,1,ipts) = -1;  
        dNdu(1,2,ipts) =  1;
        dNdu(1,3,ipts) =  0;
        dNdu(2,1,ipts) = -1;  
        dNdu(2,2,ipts) =  0;
        dNdu(2,3,ipts) =  1;
    
end

%% element loop
for iel=1:nel
    index_el=elems(iel,:);
    nodes_el = nodes(elems(iel,:),:);
    B_el = zeros(3,ndofel);  
    mu=mat_el(iel,1);
    lambda=mat_el(iel,2);
    rho=mat_el(iel,3);
    D=[2*mu+lambda, lambda, 0; lambda, 2*mu+lambda, 0; 0, 0, mu];
    u_el=[uhx(index_el(1));uhy(index_el(1));uhx(index_el(2));uhy(index_el(2));uhx(index_el(3));uhy(index_el(3))]; %change it, less explicit, not uhx and uhy but indexes
    for ipts=1:npts
        dxdu=dNdu(:,:,ipts)*nodes_el;
        dudx = inv(dxdu);
        Jac = det(dxdu); 
        dNdx = dudx*dNdu(:,:,ipts);
        B_el([1,3],1:ndim:end-1) = dNdx; 
        B_el([3,2],2:ndim:end) = dNdx;
    Sigma(iel,:,ipts)=D*B_el*u_el;
    end
    
end