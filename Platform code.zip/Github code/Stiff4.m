function [K6,f6] = Stiff4(nodes6,elems6,mat_el6,bx,by);

%computes the matrices element by element, they are then assembled in the
%global matrix in the main code
%% inputs
[~,ndim]=size(nodes6);
[nel6,nnodel]=size(elems6);
ndofel=ndim*nnodel;
bx=0;
g=9.81;
%% initializations
K6=zeros(ndofel^2, nel6);
f6=zeros(ndofel,nel6);

%% integration points
nip=3;
N      = zeros(nnodel,nip);
dNdu = zeros(ndim,nnodel,nip);
dNdx  = zeros(ndim,nnodel);

%% shape functions
U=[0;1;0];
V=[0;0;1];
gw=1/2*[1/3 1/3 1/3];
for i=1:nip %ip

        N(1,i) = -U(i)-V(i)+1;
        N(2,i) = U(i);
        N(3,i) = V(i);
        dNdu(1,1,i) = -1;  
        dNdu(1,2,i) =  1;
        dNdu(1,3,i) =  0;
        dNdu(2,1,i) = -1;  
        dNdu(2,2,i) =  0;
        dNdu(2,3,i) =  1;
    
end

%% element loop
for iel=1:nel6
    nodes_el = nodes6(elems6(iel,:),:);
    B_el = zeros(3,ndofel);
    K_el6 = zeros(ndofel);  
    f_el6 = zeros(ndofel,1);
    mu=mat_el6(iel,1);
    lambda=mat_el6(iel,2);
    rho=mat_el6(iel,3);
    D=[2*mu+lambda, lambda, 0; lambda, 2*mu+lambda, 0; 0, 0, mu];
    element_area=0.5*det([nodes_el(1,:) 1; nodes_el(2,:) 1;nodes_el(3,:) 1]);
    by=-rho*g;
    
    for i=1:nip
        dxdu=dNdu(:,:,i)*nodes_el;
        dudx = inv(dxdu);
        Jac = det(dxdu); 
        dNdx = dudx*dNdu(:,:,i);
        gwt = Jac*gw(i);
        B_el([1,3],1:ndim:end-1) = dNdx; 
        B_el([3,2],2:ndim:end) = dNdx;
        K_el6 = K_el6 + gwt*B_el'*D*B_el;
        f_el6(1:ndim:end-1) = f_el6(1:ndim:end-1) + gwt*bx*N(:,i);
        f_el6(2:ndim:end) = f_el6(2:ndim:end) + gwt*by*N(:,i);
         
    end
    K6(:,iel)=K_el6(:);
    f6(:,iel)=f_el6(:);
    
end
